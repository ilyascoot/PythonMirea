def reverse_string(string):
    return string[::-1]

def count_words(string):
    return len(string.split())