import setuptools

setuptools.setup(
    name='my_package', # Имя пакета
    version='0.0.1',  # Версия пакета
    author='Your Name',
    author_email='your@domain.com',
    description='My Package',
    packages=setuptools.find_packages(),
)